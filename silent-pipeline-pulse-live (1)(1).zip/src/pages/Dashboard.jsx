import React, { useState, useEffect, useCallback, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import DashboardHeader from '@/components/dashboard/DashboardHeader';
import LeakStatusCard from '@/components/dashboard/LeakStatusCard';
import SignalChart from '@/components/dashboard/SignalChart';
import ModelMetricsCard from '@/components/dashboard/ModelMetricsCard';
import AlertHistoryTable from '@/components/dashboard/AlertHistoryTable';
import SystemStatusPanel from '@/components/dashboard/SystemStatusPanel';

export default function Dashboard() {
  const [readings, setReadings] = useState([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [updateInterval, setUpdateInterval] = useState(null);
  const lastUpdateRef = useRef(null);
  const intervalRef = useRef(null);
  const queryClient = useQueryClient();

  // Fetch model metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ['modelMetrics'],
    queryFn: async () => {
      const res = await base44.functions.invoke('getModelMetrics', {});
      return res.data;
    },
    refetchInterval: 15000,
  });

  // Load initial readings
  useEffect(() => {
    const loadInitial = async () => {
      const data = await base44.entities.SensorReading.list('-created_date', 60);
      setReadings(data.reverse());
      if (data.length > 0) {
        setLastUpdate(data[data.length - 1].timestamp);
      }
    };
    loadInitial();
  }, []);

  // Real-time subscription to new readings
  useEffect(() => {
    const unsubscribe = base44.entities.SensorReading.subscribe((event) => {
      if (event.type === 'create' && event.data) {
        const now = Date.now();
        if (lastUpdateRef.current) {
          setUpdateInterval(now - lastUpdateRef.current);
        }
        lastUpdateRef.current = now;

        setReadings(prev => {
          const updated = [...prev, event.data];
          return updated.slice(-120); // Keep last 120 readings
        });
        setLastUpdate(event.data.timestamp);
        setIsStreaming(true);
      }
    });

    return unsubscribe;
  }, []);

  // Simulate data via polling the backend simulator
  const simulateData = useCallback(async () => {
    try {
      await base44.functions.invoke('simulateSensor', { batch_size: 1 });
    } catch (err) {
      console.error('Simulation error:', err);
      setIsStreaming(false);
    }
  }, []);

  // Start/stop simulation
  const [simRunning, setSimRunning] = useState(false);

  const toggleSimulation = useCallback(() => {
    if (simRunning) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
      setSimRunning(false);
      setIsStreaming(false);
    } else {
      simulateData(); // immediate first call
      intervalRef.current = setInterval(simulateData, 1000);
      setSimRunning(true);
      setIsStreaming(true);
    }
  }, [simRunning, simulateData]);

  // Cleanup
  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  // Detect stale stream
  useEffect(() => {
    const staleCheck = setInterval(() => {
      if (lastUpdate && Date.now() - new Date(lastUpdate).getTime() > 3000) {
        setIsStreaming(false);
      }
    }, 1000);
    return () => clearInterval(staleCheck);
  }, [lastUpdate]);

  const latestReading = readings.length > 0 ? readings[readings.length - 1] : null;

  return (
    <div className="min-h-screen bg-slate-950">
      <DashboardHeader 
        isConnected={isStreaming} 
        lastUpdate={lastUpdate} 
        updateInterval={updateInterval} 
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Simulation Control */}
        <div className="flex items-center justify-between bg-slate-800/30 border border-slate-700/30 rounded-xl px-5 py-3">
          <div>
            <p className="text-sm text-slate-300 font-medium">Data Simulator</p>
            <p className="text-xs text-slate-500">Generates sensor readings every 1 second</p>
          </div>
          <button
            onClick={toggleSimulation}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
              simRunning 
                ? 'bg-red-500/20 text-red-400 border border-red-500/30 hover:bg-red-500/30'
                : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30'
            }`}
          >
            {simRunning ? 'Stop Simulation' : 'Start Simulation'}
          </button>
        </div>

        {/* Top Row: Status + Metrics */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <LeakStatusCard latestReading={latestReading} />
          </div>
          <div className="lg:col-span-1">
            <ModelMetricsCard metrics={metrics} isLoading={metricsLoading} />
          </div>
          <div className="lg:col-span-1">
            <SystemStatusPanel 
              isConnected={isStreaming}
              lastUpdate={lastUpdate}
              updateInterval={updateInterval}
              readingCount={readings.length}
            />
          </div>
        </div>

        {/* Chart */}
        <SignalChart readings={readings} />

        {/* Alert History */}
        <AlertHistoryTable readings={readings} />
      </main>
    </div>
  );
}