import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, CheckCircle2, History } from 'lucide-react';

export default function AlertHistoryTable({ readings }) {
  const alertReadings = (readings || [])
    .filter(r => r.is_alert || r.pipeline_status === 'leak_detected')
    .slice(0, 20);

  const recentNormal = (readings || [])
    .filter(r => r.pipeline_status === 'normal')
    .slice(0, 5);

  const display = [...alertReadings, ...recentNormal]
    .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
    .slice(0, 15);

  return (
    <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <History className="w-4 h-4 text-slate-400" />
          <h3 className="text-sm font-semibold text-slate-200">Detection History</h3>
          {alertReadings.length > 0 && (
            <Badge className="bg-red-500/15 text-red-400 border-red-500/30 text-[10px] px-2">
              {alertReadings.length} alerts
            </Badge>
          )}
        </div>

        {display.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-sm">
            No detection events yet
          </div>
        ) : (
          <div className="overflow-x-auto max-h-[350px] overflow-y-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700/50 hover:bg-transparent">
                  <TableHead className="text-slate-500 text-[10px] uppercase tracking-wider">Status</TableHead>
                  <TableHead className="text-slate-500 text-[10px] uppercase tracking-wider">Segment</TableHead>
                  <TableHead className="text-slate-500 text-[10px] uppercase tracking-wider">Signal</TableHead>
                  <TableHead className="text-slate-500 text-[10px] uppercase tracking-wider">Confidence</TableHead>
                  <TableHead className="text-slate-500 text-[10px] uppercase tracking-wider">Timestamp</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {display.map((r, i) => {
                  const isLeak = r.pipeline_status === 'leak_detected';
                  return (
                    <TableRow key={r.id || i} className="border-slate-700/30 hover:bg-slate-700/20">
                      <TableCell>
                        <div className="flex items-center gap-1.5">
                          {isLeak ? (
                            <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                          ) : (
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                          )}
                          <span className={`text-xs font-medium ${isLeak ? 'text-red-400' : 'text-emerald-400'}`}>
                            {isLeak ? 'Leak' : 'Normal'}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-slate-300 font-mono">{r.segment}</span>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs text-slate-300 font-mono">{r.signal_value?.toFixed(4)}</span>
                      </TableCell>
                      <TableCell>
                        <span className={`text-xs font-mono font-medium ${isLeak ? 'text-red-300' : 'text-emerald-300'}`}>
                          {(r.confidence * 100).toFixed(1)}%
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(r.timestamp).toLocaleString()}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}