import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, CheckCircle2, MapPin, Clock, Activity } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function LeakStatusCard({ latestReading }) {
  if (!latestReading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700/50 backdrop-blur">
        <CardContent className="p-6 text-center text-slate-400">
          <Activity className="w-8 h-8 mx-auto mb-2 animate-pulse" />
          <p className="text-sm">Waiting for stream...</p>
        </CardContent>
      </Card>
    );
  }

  const isLeak = latestReading.pipeline_status === 'leak_detected';
  const confidencePct = (latestReading.confidence * 100).toFixed(1);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={latestReading.pipeline_status}
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.3 }}
      >
        <Card className={`border backdrop-blur overflow-hidden relative ${
          isLeak 
            ? 'bg-red-950/50 border-red-500/40' 
            : 'bg-emerald-950/30 border-emerald-500/30'
        }`}>
          {isLeak && (
            <div className="absolute inset-0 bg-red-500/5 animate-pulse" />
          )}
          <CardContent className="p-6 relative">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                {isLeak ? (
                  <div className="w-12 h-12 rounded-xl bg-red-500/20 flex items-center justify-center">
                    <AlertTriangle className="w-6 h-6 text-red-400" />
                  </div>
                ) : (
                  <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                  </div>
                )}
                <div>
                  <p className="text-xs text-slate-400 uppercase tracking-wider font-medium">Pipeline Status</p>
                  <p className={`text-xl font-bold tracking-tight ${isLeak ? 'text-red-400' : 'text-emerald-400'}`}>
                    {isLeak ? 'LEAK DETECTED' : 'NORMAL'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 mt-4">
              <div className="bg-slate-900/50 rounded-lg p-3">
                <div className="flex items-center gap-1.5 mb-1">
                  <Activity className="w-3 h-3 text-slate-500" />
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Confidence</span>
                </div>
                <p className={`text-lg font-bold ${isLeak ? 'text-red-300' : 'text-emerald-300'}`}>
                  {confidencePct}%
                </p>
              </div>
              <div className="bg-slate-900/50 rounded-lg p-3">
                <div className="flex items-center gap-1.5 mb-1">
                  <MapPin className="w-3 h-3 text-slate-500" />
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Segment</span>
                </div>
                <p className="text-lg font-bold text-slate-200">
                  {latestReading.segment}
                </p>
              </div>
              <div className="bg-slate-900/50 rounded-lg p-3">
                <div className="flex items-center gap-1.5 mb-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Time</span>
                </div>
                <p className="text-sm font-mono font-bold text-slate-200">
                  {new Date(latestReading.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>

            {/* Signal strength bar */}
            <div className="mt-4">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider">Signal Level</span>
                <span className="text-xs text-slate-400 font-mono">{latestReading.signal_value?.toFixed(4)}</span>
              </div>
              <div className="h-2 bg-slate-900/80 rounded-full overflow-hidden">
                <motion.div 
                  className={`h-full rounded-full ${isLeak ? 'bg-gradient-to-r from-red-500 to-red-400' : 'bg-gradient-to-r from-emerald-500 to-teal-400'}`}
                  initial={{ width: 0 }}
                  animate={{ width: `${(latestReading.signal_value || 0) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </AnimatePresence>
  );
}